#!/bin/bash
#PBS -q normal
#PBS -l walltime=00:30:00
#PBS -l ncpus=384
#PBS -l mem=192gb
#PBS -M 1486481250@qq.com
#PBS -m abe
#PBS -P af36
#PBS -N md_1_384

source ~/.bashrc
export CC=mpiicc
export CXX=mpiicpc
export FC=mpiifort
conda init
conda activate wzx-hoomd
module load eigen
module load intel-mpi
module load intel-compiler
cd /home/552/zw5666/hoomd-benchmarks

mpirun -n 384 python -m hoomd_benchmarks.md_pair_wca --device CPU -N 200000 --warmup_steps 40000 --benchmark_steps 80000 --repeat 1 -v
